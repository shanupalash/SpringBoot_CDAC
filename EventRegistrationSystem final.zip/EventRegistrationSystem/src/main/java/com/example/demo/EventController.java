	package com.example.demo;
	
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Controller;
	import org.springframework.ui.Model;
	import org.springframework.web.bind.annotation.*;
	
	import jakarta.servlet.http.HttpSession;
	
	@Controller
	public class EventController {
	
	    @Autowired
	    private EventRegistrationRepository repository;
	
	    @GetMapping("/")
	    public String homeRedirect() {
	        return "redirect:/register";
	    }
	
	    @GetMapping("/register")
	    public String showRegistrationForm(Model model) {
	        model.addAttribute("eventRegistration", new EventRegistration());
	        return "register";
	    }
	
	    @PostMapping("/register")
	    public String register(@ModelAttribute EventRegistration eventRegistration, Model model) {
	        EventRegistration saved = repository.save(eventRegistration);
	        model.addAttribute("participant", saved);
	        return "view"; 
	    }
	
	    @GetMapping("/participants")
	    public String viewParticipants(Model model) {
	        model.addAttribute("participants", repository.findAll());
	        return "viewParticipants";
	    }
	    
	    
	    @GetMapping("/edit/{id}")
	    public String editForm(@PathVariable Long id, Model model) {
	        EventRegistration reg = repository.findById(id)
	                .orElseThrow(() -> new IllegalArgumentException("Invalid ID: " + id));
	        model.addAttribute("eventRegistration", reg);
	        return "edit";
	    }
	
	    @PostMapping("/update")
	    public String updateParticipant(@ModelAttribute EventRegistration eventRegistration) {
	        repository.save(eventRegistration); // works for update too
	        return "redirect:/participants";
	    }
	
	    @GetMapping("/delete/{id}")
	    public String deleteParticipant(@PathVariable Long id) {
	        repository.deleteById(id);
	        return "redirect:/participants";
	    }
	    
	    
	    
	    private static final String USERNAME = "admin";
	    private static final String PASSWORD = "password123";
	
	   
	    
	    @GetMapping("/login")
	    public String showLoginForm() {
	        return "login"; // Corresponds to /WEB-INF/views/adminLogin.jsp
	    }
	
	    @PostMapping("/login")
	    public String login(@RequestParam String username,
	                        @RequestParam String password,
	                        HttpSession session,
	                        Model model) {
	        if ("admin".equals(username) && "admin".equals(password)) {
	            session.setAttribute("admin", true);
	            return "redirect:/participants";
	        } else {
	            model.addAttribute("error", "Invalid username or password");
	            return "login";
	        }
	    }
	
	    
	    
	    
	}
